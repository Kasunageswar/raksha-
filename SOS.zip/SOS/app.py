from flask import Flask, request, jsonify, redirect, url_for, render_template, session
from pymongo import MongoClient
from bson import ObjectId
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)

client = MongoClient("mongodb://localhost:27017/") 
db = client["sos_app"]  
users_collection = db["users"]  
app.secret_key = 'your_secret_key'


@app.route('/')
def home():
    return render_template('index.html')

@app.route('/loginpage')
def loginpage():
    return render_template('login.html')

@app.route('/signuppage')
def signuppage():
    return render_template('signup.html')

@app.route('/mainpage')
def mainpage():
    if 'user_id' not in session:
        return redirect(url_for('loginpage'))

    user = users_collection.find_one({"_id": ObjectId(session['user_id'])})

    return render_template('main.html', name=user['name'], email=user['email'])

@app.route('/api/getContacts', methods=['GET'])
def get_contacts():
    user = users_collection.find_one({"_id": ObjectId(session['user_id'])})  # Modify the filter as per your requirement
    if user and 'contacts' in user:
        return jsonify(user['contacts'])  # Return the list of contacts
    else:
        return jsonify([])


@app.route('/register_sos', methods=['GET', 'POST'])
def register_sos():
    if request.method == 'POST':
        # Get form data
        name = request.form['name']
        email = request.form['email']
        mobile = request.form['mobile']
        contact1 = request.form['contact1']
        contact2 = request.form['contact2']
        contact3 = request.form['contact3']
        contact4 = request.form['contact4']
        contact5 = request.form['contact5']
        password = request.form['password']
        confirm_password = request.form['confirm-password']
        
        # Check if passwords match (optional on server side)
        if password != confirm_password:
            return "Passwords do not match, please try again.", 400

        # Hash password using Werkzeug's generate_password_hash
        hashed_password = generate_password_hash(password)

        # Create user data
        user_data = {
            'name': name,
            'email': email,
            'mobile': mobile,
            'contacts': [contact1, contact2, contact3, contact4, contact5],
            'password': hashed_password
        }

        # Insert user data into MongoDB
        users_collection.insert_one(user_data)

        # Redirect to login or another page after successful registration
        return redirect(url_for('loginpage'))

    return render_template('register.html')
# Login route
@app.route('/login', methods=['POST'])
def login():
    # Get login data
    email = request.form.get("email")
    password = request.form.get("password")  # For simplicity, using the mobile number as the password

 
    user = users_collection.find_one({"email": email})
    if not user:
        return jsonify({"success": False, "message": "Invalid email or password!"}), 400

    if check_password_hash(user['password'], password):
        session["user_id"] = str(user["_id"])
        return jsonify({"success": True, "message": "Login successful!"}), 200
    else:
        return jsonify({"success": False, "message": "Invalid email or password!"}), 400

# Logout route
@app.route('/logout', methods=['GET'])
def logout():
    session.pop("user_id", None)  # Clear user session
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
